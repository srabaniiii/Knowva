import { useState, useEffect, useRef } from "react";

// ─── MOCK DATA ────────────────────────────────────────────────────────────────
const MOCK_COMPANY = {
  company_name: "NovaTech Solutions",
  plan: "trial",
  trial_start_date: new Date(Date.now() - 5 * 86400000),
  trial_end_date: new Date(Date.now() + 25 * 86400000),
  subscription_status: "active",
  employee_limit: 50,
};

const INITIAL_EMPLOYEES = [
  { id: "e1", name: "Ananya Sharma", email: "ananya@novatech.com", role: "Employee", department: "Operations", status: "Active", projects: ["p1", "p2"], avatar: "AS", joined: "2022-03-15", critical: true },
  { id: "e2", name: "Rahul Mehta", email: "rahul@novatech.com", role: "Employee", department: "Operations", status: "Active", projects: ["p2"], avatar: "RM", joined: "2023-01-10", critical: false },
  { id: "e3", name: "Priya Kapoor", email: "priya@novatech.com", role: "HR", department: "HR", status: "Active", projects: [], avatar: "PK", joined: "2021-08-20", critical: false },
  { id: "e4", name: "Arjun Singh", email: "arjun@novatech.com", role: "Employee", department: "Engineering", status: "Active", projects: ["p1"], avatar: "AS2", joined: "2022-11-05", critical: false },
  { id: "e5", name: "Sneha Nair", email: "sneha@novatech.com", role: "Employee", department: "Sales", status: "Active", projects: [], avatar: "SN", joined: "2023-06-01", critical: false },
];

const INITIAL_PROJECTS = [
  { id: "p1", project_name: "CRM Optimization", client_name: "RetailMax Ltd.", assigned_to: ["e1", "e4"], status: "Active" },
  { id: "p2", project_name: "Sales Analytics Dashboard", client_name: "FinServe Corp.", assigned_to: ["e1", "e2"], status: "Active" },
];

const INITIAL_SOPS = [
  { id: "s1", title: "Monthly Reporting SOP", description: "Step-by-step guide for monthly performance reporting including data collection, analysis, and stakeholder presentation.", file_url: "#", version: "v2.1", project_id: "p1", created_by: "e1", tags: ["reporting", "monthly", "operations"], created_at: "2024-01-15", coverage: 90 },
  { id: "s2", title: "Client Escalation SOP", description: "Protocol for handling client escalations, defining response time SLAs, escalation matrix, and resolution documentation.", file_url: "#", version: "v1.3", project_id: "p1", created_by: "e1", tags: ["client", "escalation", "support"], created_at: "2024-02-20", coverage: 75 },
  { id: "s3", title: "Employee Onboarding SOP", description: "Complete onboarding checklist for new employees including system access, introductory meetings, and 30-60-90 day goals.", file_url: "#", version: "v3.0", project_id: null, created_by: "e3", tags: ["onboarding", "hr", "people"], created_at: "2023-11-10", coverage: 95 },
];

const INITIAL_TRANSITIONS = [];

const AUDIT_LOGS_INIT = [
  { id: "a1", action: "Company created", performed_by: "System", timestamp: new Date(Date.now() - 5*86400000), type: "system" },
  { id: "a2", action: "5 employees added", performed_by: "Priya Kapoor", timestamp: new Date(Date.now() - 4*86400000), type: "employee" },
  { id: "a3", action: "SOP uploaded: Monthly Reporting SOP", performed_by: "Ananya Sharma", timestamp: new Date(Date.now() - 3*86400000), type: "sop" },
  { id: "a4", action: "SOP uploaded: Client Escalation SOP", performed_by: "Ananya Sharma", timestamp: new Date(Date.now() - 2*86400000), type: "sop" },
];

const AI_RESPONSES = {
  default: "I can help you analyze knowledge risk, summarize SOPs, and identify transition gaps. Try asking me about departments, employees, or specific SOPs.",
  risk: (employees, sops, transitions) => {
    const resigned = employees.filter(e => e.status === "Resigned");
    const active = employees.filter(e => e.status === "Active");
    const avgCoverage = sops.reduce((s, x) => s + x.coverage, 0) / (sops.length || 1);
    return `📊 **Knowledge Risk Analysis**\n\n🔴 **Operations** — ${resigned.length > 0 ? "HIGH RISK" : "MODERATE"}: ${resigned.length} resignation(s) pending. ${resigned.map(e => e.name).join(", ")} held ${resigned.reduce((s, e) => s + e.projects.length, 0)} project(s).\n\n🟡 **Sales** — MEDIUM RISK: No dedicated SOP coverage detected.\n\n🟢 **Engineering** — LOW RISK: Arjun Singh covers 1 project with adequate documentation.\n\n📁 Overall SOP Coverage: ${Math.round(avgCoverage)}%\n🔄 Active Transitions: ${transitions.length}`;
  },
  sop: (sops) => `📘 **SOP Summary**\n\nYou have ${sops.length} SOPs across your vault:\n\n${sops.map(s => `• **${s.title}** (${s.version}) — ${s.coverage}% coverage, tags: ${s.tags.join(", ")}`).join("\n")}\n\n⚠️ Recommendation: "Client Escalation SOP" at 75% is below the 80% threshold. Consider updating before the next exit cycle.`,
  trend: (employees) => {
    const resigned = employees.filter(e => e.status === "Resigned");
    return `📈 **Resignation Trend Analysis**\n\nLast 30 days: ${resigned.length} resignation(s) detected.\n${resigned.length > 0 ? `\nExiting employees: ${resigned.map(e => `${e.name} (${e.department})`).join(", ")}\n\nImpacted projects: ${[...new Set(resigned.flatMap(e => e.projects))].length} project(s)\n\n⚠️ This is above average for your company size. Review retention strategy for Operations.` : "\nNo resignations in the current period. Retention health looks ✅ great!"}`; 
  },
};

function timeAgo(date) {
  const diff = Date.now() - new Date(date).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  return `${Math.floor(hrs / 24)}d ago`;
}

function daysLeft(date) {
  return Math.max(0, Math.ceil((new Date(date) - Date.now()) / 86400000));
}

// ─── STYLES ──────────────────────────────────────────────────────────────────
const S = {
  app: { fontFamily: "'Outfit', system-ui, sans-serif", background: "#080c14", color: "#dce4f0", minHeight: "100vh", display: "flex" },
  sidebar: { width: 240, background: "#0c1220", borderRight: "1px solid rgba(99,179,237,0.1)", display: "flex", flexDirection: "column", flexShrink: 0, position: "fixed", top: 0, bottom: 0, left: 0, zIndex: 50 },
  main: { marginLeft: 240, flex: 1, display: "flex", flexDirection: "column", minHeight: "100vh" },
  topbar: { background: "rgba(12,18,32,0.9)", backdropFilter: "blur(12px)", borderBottom: "1px solid rgba(99,179,237,0.08)", padding: "0 28px", height: 60, display: "flex", alignItems: "center", justifyContent: "space-between", position: "sticky", top: 0, zIndex: 40 },
  content: { padding: "28px 32px", flex: 1 },
  card: { background: "#0f1826", border: "1px solid rgba(99,179,237,0.1)", borderRadius: 16, padding: 24 },
  cardSm: { background: "#0f1826", border: "1px solid rgba(99,179,237,0.1)", borderRadius: 14, padding: 18 },
  btn: { border: "none", cursor: "pointer", borderRadius: 10, fontFamily: "inherit", fontWeight: 600, transition: "all 0.2s" },
  input: { background: "rgba(255,255,255,0.05)", border: "1px solid rgba(99,179,237,0.2)", borderRadius: 10, color: "#dce4f0", fontFamily: "inherit", outline: "none", transition: "border-color 0.2s" },
  badge: (color) => ({ background: color + "22", border: `1px solid ${color}55`, borderRadius: 6, padding: "2px 8px", fontSize: 11, color, fontWeight: 600, display: "inline-block" }),
  tag: { background: "rgba(99,179,237,0.1)", border: "1px solid rgba(99,179,237,0.2)", borderRadius: 100, padding: "2px 10px", fontSize: 11, color: "#7dd3fc" },
};

// ─── AUTH SCREEN ──────────────────────────────────────────────────────────────
function AuthScreen({ onLogin }) {
  const [tab, setTab] = useState("login");
  const [form, setForm] = useState({ email: "", password: "", company: "" });
  const [loading, setLoading] = useState(false);

  const handle = () => {
    setLoading(true);
    setTimeout(() => { setLoading(false); onLogin({ email: form.email || "hr@novatech.com", name: "Priya Kapoor", role: "HR" }); }, 1200);
  };

  return (
    <div style={{ minHeight: "100vh", background: "#080c14", display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "'Outfit',sans-serif", position: "relative", overflow: "hidden" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&family=Syne:wght@700;800&display=swap');
        @keyframes float { 0%,100%{transform:translateY(0)}50%{transform:translateY(-10px)} }
        @keyframes spin-slow { from{transform:rotate(0deg)}to{transform:rotate(360deg)} }
        @keyframes fade-in { from{opacity:0;transform:translateY(20px)}to{opacity:1;transform:translateY(0)} }
        @keyframes shimmer { 0%{background-position:-200% 0}100%{background-position:200% 0} }
        .auth-card { animation: fade-in 0.6s ease both; }
        .auth-btn { animation: none; background: linear-gradient(135deg, #3b82f6, #8b5cf6); border: none; cursor: pointer; color: white; font-family: inherit; font-weight: 700; font-size: 15px; padding: 14px; border-radius: 12px; width: 100%; transition: all 0.2s; }
        .auth-btn:hover { transform: translateY(-2px); box-shadow: 0 10px 30px rgba(99,102,241,0.4); }
        .auth-input { background: rgba(255,255,255,0.04); border: 1px solid rgba(99,179,237,0.2); border-radius: 12px; color: #dce4f0; font-family: inherit; font-size: 14px; padding: 13px 16px; width: 100%; outline: none; box-sizing: border-box; }
        .auth-input:focus { border-color: rgba(99,102,241,0.6); }
        .auth-input::placeholder { color: rgba(220,228,240,0.3); }
        .shimmer-text { background: linear-gradient(90deg, #93c5fd, #fff, #a5b4fc, #93c5fd); background-size: 200% auto; -webkit-background-clip: text; -webkit-text-fill-color: transparent; animation: shimmer 3s linear infinite; }
        .tab-btn { border: none; cursor: pointer; background: transparent; font-family: inherit; font-size: 14px; font-weight: 600; padding: 8px 20px; border-radius: 8px; transition: all 0.2s; }
      `}</style>

      {/* bg orbs */}
      <div style={{ position: "absolute", width: 500, height: 500, borderRadius: "50%", background: "radial-gradient(circle, rgba(99,102,241,0.12) 0%, transparent 70%)", top: "10%", left: "10%", animation: "float 6s ease-in-out infinite" }} />
      <div style={{ position: "absolute", width: 400, height: 400, borderRadius: "50%", background: "radial-gradient(circle, rgba(59,130,246,0.1) 0%, transparent 70%)", bottom: "10%", right: "10%", animation: "float 8s ease-in-out infinite reverse" }} />

      <div className="auth-card" style={{ width: 420, background: "#0f1826", border: "1px solid rgba(99,179,237,0.15)", borderRadius: 24, padding: 40, position: "relative", zIndex: 1 }}>
        <div style={{ textAlign: "center", marginBottom: 32 }}>
          <div style={{ width: 52, height: 52, borderRadius: 16, background: "linear-gradient(135deg,#3b82f6,#8b5cf6)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 24, margin: "0 auto 16px" }}>🧠</div>
          <div style={{ fontFamily: "'Syne',sans-serif", fontWeight: 800, fontSize: 28, letterSpacing: "-1px" }} className="shimmer-text">Knowva</div>
          <div style={{ fontSize: 13, color: "rgba(220,228,240,0.45)", marginTop: 4 }}>Because knowledge should stay.</div>
        </div>

        <div style={{ display: "flex", background: "rgba(255,255,255,0.04)", borderRadius: 12, padding: 4, marginBottom: 28 }}>
          {["login", "signup"].map(t => (
            <button key={t} className="tab-btn" onClick={() => setTab(t)} style={{ flex: 1, color: tab === t ? "white" : "rgba(220,228,240,0.45)", background: tab === t ? "rgba(99,102,241,0.3)" : "transparent" }}>
              {t === "login" ? "Log In" : "Sign Up"}
            </button>
          ))}
        </div>

        <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
          {tab === "signup" && (
            <input className="auth-input" placeholder="Company name" value={form.company} onChange={e => setForm({ ...form, company: e.target.value })} />
          )}
          <input className="auth-input" placeholder="Email address" type="email" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} />
          <input className="auth-input" placeholder="Password" type="password" value={form.password} onChange={e => setForm({ ...form, password: e.target.value })} />
          <button className="auth-btn" onClick={handle} style={{ marginTop: 6 }}>
            {loading ? "⏳ Authenticating..." : tab === "login" ? "→ Log In" : "✨ Start Free 30-Day Trial"}
          </button>
        </div>

        <div style={{ marginTop: 20, textAlign: "center" }}>
          <div style={{ fontSize: 12, color: "rgba(220,228,240,0.3)", marginBottom: 10 }}>— or try the demo —</div>
          <button onClick={() => handle()} style={{ background: "rgba(59,130,246,0.1)", border: "1px solid rgba(59,130,246,0.3)", color: "#93c5fd", borderRadius: 10, padding: "10px 24px", cursor: "pointer", fontFamily: "inherit", fontWeight: 600, fontSize: 13, transition: "all 0.2s" }}>
            🚀 Login as NovaTech HR Demo
          </button>
        </div>

        <div style={{ marginTop: 24, display: "flex", justifyContent: "center", gap: 16, flexWrap: "wrap" }}>
          {["✓ No credit card", "✓ 30-day free trial", "✓ 50 employees"].map(t => (
            <span key={t} style={{ fontSize: 11, color: "rgba(220,228,240,0.35)" }}>{t}</span>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── SIDEBAR ──────────────────────────────────────────────────────────────────
const NAV = [
  { id: "dashboard", icon: "⬡", label: "Dashboard" },
  { id: "employees", icon: "👥", label: "Employees" },
  { id: "sops", icon: "📁", label: "SOP Vault" },
  { id: "projects", icon: "🗂", label: "Projects" },
  { id: "transitions", icon: "🔄", label: "Transitions" },
  { id: "analytics", icon: "📊", label: "Analytics" },
  { id: "ai", icon: "✨", label: "Ask Knowva AI" },
  { id: "billing", icon: "💳", label: "Billing" },
];

function Sidebar({ active, setActive, company }) {
  const days = daysLeft(company.trial_end_date);
  return (
    <div style={S.sidebar}>
      <div style={{ padding: "20px 20px 16px", borderBottom: "1px solid rgba(99,179,237,0.08)" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <div style={{ width: 36, height: 36, borderRadius: 11, background: "linear-gradient(135deg,#3b82f6,#8b5cf6)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 17 }}>🧠</div>
          <div>
            <div style={{ fontFamily: "'Syne',sans-serif", fontWeight: 800, fontSize: 17, color: "white", letterSpacing: "-0.5px" }}>Knowva</div>
            <div style={{ fontSize: 10, color: "rgba(220,228,240,0.4)" }}>{company.company_name}</div>
          </div>
        </div>
      </div>

      <nav style={{ padding: "12px 10px", flex: 1 }}>
        {NAV.map(n => (
          <button key={n.id} onClick={() => setActive(n.id)} style={{ width: "100%", display: "flex", alignItems: "center", gap: 12, padding: "10px 12px", borderRadius: 10, marginBottom: 2, border: "none", cursor: "pointer", fontFamily: "inherit", fontSize: 13, fontWeight: 500, background: active === n.id ? "rgba(99,102,241,0.2)" : "transparent", color: active === n.id ? "#a5b4fc" : "rgba(220,228,240,0.55)", transition: "all 0.15s", textAlign: "left", borderLeft: active === n.id ? "2px solid #6366f1" : "2px solid transparent" }}>
            <span style={{ fontSize: 16 }}>{n.icon}</span> {n.label}
            {n.id === "transitions" && <span style={{ marginLeft: "auto", background: "#ef444422", border: "1px solid #ef444455", borderRadius: 100, padding: "1px 7px", fontSize: 10, color: "#f87171" }}>LIVE</span>}
            {n.id === "ai" && <span style={{ marginLeft: "auto", background: "#8b5cf622", border: "1px solid #8b5cf655", borderRadius: 100, padding: "1px 7px", fontSize: 10, color: "#c4b5fd" }}>AI</span>}
          </button>
        ))}
      </nav>

      <div style={{ padding: "12px 14px", borderTop: "1px solid rgba(99,179,237,0.08)" }}>
        <div style={{ background: "rgba(251,191,36,0.08)", border: "1px solid rgba(251,191,36,0.2)", borderRadius: 12, padding: "12px 14px" }}>
          <div style={{ fontSize: 11, fontWeight: 700, color: "#fbbf24", marginBottom: 4 }}>⏰ TRIAL ACTIVE</div>
          <div style={{ fontSize: 12, color: "rgba(220,228,240,0.6)", marginBottom: 8 }}>{days} days remaining</div>
          <div style={{ background: "rgba(255,255,255,0.08)", borderRadius: 4, height: 4, marginBottom: 10 }}>
            <div style={{ background: "linear-gradient(90deg,#fbbf24,#f59e0b)", height: 4, borderRadius: 4, width: `${(days / 30) * 100}%`, transition: "width 1s" }} />
          </div>
          <button style={{ ...S.btn, background: "linear-gradient(135deg,#3b82f6,#8b5cf6)", color: "white", padding: "8px", width: "100%", fontSize: 12 }}>Upgrade Now</button>
        </div>
      </div>
    </div>
  );
}

// ─── DASHBOARD PAGE ───────────────────────────────────────────────────────────
function DashboardPage({ employees, sops, transitions, auditLogs, setPage }) {
  const active = employees.filter(e => e.status === "Active").length;
  const resigned = employees.filter(e => e.status === "Resigned").length;
  const avgCoverage = Math.round(sops.reduce((s, x) => s + x.coverage, 0) / (sops.length || 1));
  const riskScore = resigned > 0 && avgCoverage < 80 ? "High" : resigned > 0 ? "Medium" : "Low";
  const riskColor = { High: "#ef4444", Medium: "#f59e0b", Low: "#10b981" }[riskScore];

  const stats = [
    { label: "Total Employees", value: employees.length, icon: "👥", color: "#3b82f6", sub: `${active} active` },
    { label: "Active Transitions", value: transitions.length, icon: "🔄", color: "#f59e0b", sub: transitions.length > 0 ? "Action needed" : "All clear" },
    { label: "SOP Coverage", value: avgCoverage + "%", icon: "📁", color: "#10b981", sub: `${sops.length} SOPs total` },
    { label: "Knowledge Risk", value: riskScore, icon: "📊", color: riskColor, sub: resigned + " resignation(s)" },
  ];

  return (
    <div>
      <h1 style={{ fontFamily: "'Syne',sans-serif", fontWeight: 800, fontSize: 26, color: "white", marginBottom: 6, letterSpacing: "-0.5px" }}>Dashboard</h1>
      <p style={{ color: "rgba(220,228,240,0.45)", fontSize: 14, marginBottom: 28 }}>Welcome back, Priya 👋 Here's NovaTech's knowledge health today.</p>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 18, marginBottom: 28 }}>
        {stats.map(s => (
          <div key={s.label} style={{ ...S.card, borderLeft: `3px solid ${s.color}` }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 12 }}>
              <span style={{ fontSize: 24 }}>{s.icon}</span>
              <span style={{ ...S.badge(s.color), fontSize: 10 }}>{s.sub}</span>
            </div>
            <div style={{ fontFamily: "'Syne',sans-serif", fontWeight: 800, fontSize: 30, color: s.color, marginBottom: 4 }}>{s.value}</div>
            <div style={{ fontSize: 13, color: "rgba(220,228,240,0.55)" }}>{s.label}</div>
          </div>
        ))}
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20 }}>
        {/* Risk Dept Breakdown */}
        <div style={S.card}>
          <div style={{ fontSize: 15, fontWeight: 700, color: "white", marginBottom: 18 }}>📊 Department Risk Breakdown</div>
          {[
            { dept: "Operations", risk: resigned > 0 ? "High" : "Low", color: resigned > 0 ? "#ef4444" : "#10b981", sop: avgCoverage, note: resigned > 0 ? `${resigned} resignation(s)` : "Fully covered" },
            { dept: "Engineering", risk: "Low", color: "#10b981", sop: 88, note: "1 project, well covered" },
            { dept: "Sales", risk: "Medium", color: "#f59e0b", sop: 55, note: "Missing 2 SOPs" },
            { dept: "HR", risk: "Low", color: "#10b981", sop: 95, note: "Fully documented" },
          ].map(d => (
            <div key={d.dept} style={{ display: "flex", alignItems: "center", gap: 14, padding: "10px 0", borderBottom: "1px solid rgba(99,179,237,0.06)" }}>
              <div style={{ width: 34, height: 34, borderRadius: 9, background: d.color + "22", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 14, border: `1px solid ${d.color}33` }}>
                {d.risk === "High" ? "🔴" : d.risk === "Medium" ? "🟡" : "🟢"}
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 13, fontWeight: 600, color: "white" }}>{d.dept}</div>
                <div style={{ fontSize: 11, color: "rgba(220,228,240,0.45)" }}>{d.note}</div>
              </div>
              <div style={{ textAlign: "right" }}>
                <div style={{ fontSize: 13, fontWeight: 700, color: d.color }}>{d.risk} Risk</div>
                <div style={{ fontSize: 11, color: "rgba(220,228,240,0.4)" }}>{d.sop}% SOP</div>
              </div>
            </div>
          ))}
        </div>

        {/* Audit Log */}
        <div style={S.card}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 18 }}>
            <div style={{ fontSize: 15, fontWeight: 700, color: "white" }}>📋 Recent Activity</div>
            <span style={{ fontSize: 12, color: "rgba(220,228,240,0.4)" }}>Live</span>
          </div>
          {auditLogs.slice(-6).reverse().map(log => (
            <div key={log.id} style={{ display: "flex", gap: 12, padding: "9px 0", borderBottom: "1px solid rgba(99,179,237,0.06)", alignItems: "flex-start" }}>
              <div style={{ width: 7, height: 7, borderRadius: "50%", background: log.type === "transition" ? "#ef4444" : log.type === "sop" ? "#3b82f6" : "#10b981", marginTop: 5, flexShrink: 0 }} />
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 13, color: "#dce4f0" }}>{log.action}</div>
                <div style={{ fontSize: 11, color: "rgba(220,228,240,0.4)" }}>by {log.performed_by} · {timeAgo(log.timestamp)}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Quick Actions */}
      <div style={{ ...S.card, marginTop: 20, display: "flex", gap: 14, alignItems: "center" }}>
        <div style={{ fontSize: 18 }}>⚡</div>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 14, fontWeight: 600, color: "white" }}>Quick Actions</div>
          <div style={{ fontSize: 12, color: "rgba(220,228,240,0.45)" }}>Jump to common tasks</div>
        </div>
        {[["Add Employee", "employees"], ["Upload SOP", "sops"], ["Start Transition", "employees"], ["View AI Insights", "ai"]].map(([l, p]) => (
          <button key={l} onClick={() => setPage(p)} style={{ ...S.btn, background: "rgba(99,102,241,0.12)", border: "1px solid rgba(99,102,241,0.25)", color: "#a5b4fc", padding: "9px 16px", fontSize: 13 }}>{l}</button>
        ))}
      </div>
    </div>
  );
}

// ─── EMPLOYEES PAGE ───────────────────────────────────────────────────────────
function EmployeesPage({ employees, setEmployees, transitions, setTransitions, auditLogs, setAuditLogs }) {
  const [showAdd, setShowAdd] = useState(false);
  const [showResign, setShowResign] = useState(null);
  const [successor, setSuccessor] = useState("");
  const [newEmp, setNewEmp] = useState({ name: "", email: "", department: "", role: "Employee" });
  const [search, setSearch] = useState("");
  const [filterStatus, setFilterStatus] = useState("All");

  const filtered = employees.filter(e =>
    (filterStatus === "All" || e.status === filterStatus) &&
    (e.name.toLowerCase().includes(search.toLowerCase()) || e.department.toLowerCase().includes(search.toLowerCase()))
  );

  const handleResign = (emp) => {
    const now = new Date();
    const newTransition = {
      id: "t" + Date.now(),
      company_id: "c1",
      exiting_employee_id: emp.id,
      exiting_name: emp.name,
      successor_id: successor,
      successor_name: employees.find(e => e.id === successor)?.name || "TBD",
      checklist_status: "In Progress",
      knowledge_transfer_status: "Pending",
      created_at: now,
      department: emp.department,
      sops_required: emp.projects.length * 2,
      sops_done: 0,
    };
    setTransitions(prev => [...prev, newTransition]);
    setEmployees(prev => prev.map(e => e.id === emp.id ? { ...e, status: "Resigned" } : e));
    setAuditLogs(prev => [
      ...prev,
      { id: "a" + Date.now(), action: `${emp.name} marked as Resigned — Auto Exit Flow initiated`, performed_by: "Priya Kapoor", timestamp: now, type: "transition" },
      { id: "a" + (Date.now() + 1), action: `Transition record created for ${emp.name}`, performed_by: "System", timestamp: now, type: "transition" },
      { id: "a" + (Date.now() + 2), action: `Successor ${employees.find(e => e.id === successor)?.name || "TBD"} assigned`, performed_by: "System", timestamp: now, type: "transition" },
    ]);
    setShowResign(null);
    setSuccessor("");
  };

  const handleAdd = () => {
    if (!newEmp.name || !newEmp.email) return;
    const emp = { ...newEmp, id: "e" + Date.now(), status: "Active", projects: [], avatar: newEmp.name.split(" ").map(w => w[0]).join("").toUpperCase(), joined: new Date().toISOString().split("T")[0], critical: false };
    setEmployees(prev => [...prev, emp]);
    setAuditLogs(prev => [...prev, { id: "a" + Date.now(), action: `New employee added: ${newEmp.name}`, performed_by: "Priya Kapoor", timestamp: new Date(), type: "employee" }]);
    setNewEmp({ name: "", email: "", department: "", role: "Employee" });
    setShowAdd(false);
  };

  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", marginBottom: 24 }}>
        <div>
          <h1 style={{ fontFamily: "'Syne',sans-serif", fontWeight: 800, fontSize: 26, color: "white", letterSpacing: "-0.5px" }}>Employees</h1>
          <p style={{ color: "rgba(220,228,240,0.45)", fontSize: 14 }}>{employees.length} members · {employees.filter(e => e.status === "Active").length} active</p>
        </div>
        <button onClick={() => setShowAdd(true)} style={{ ...S.btn, background: "linear-gradient(135deg,#3b82f6,#8b5cf6)", color: "white", padding: "11px 22px", fontSize: 14 }}>+ Add Employee</button>
      </div>

      <div style={{ display: "flex", gap: 12, marginBottom: 20 }}>
        <input style={{ ...S.input, flex: 1, padding: "10px 16px", fontSize: 14 }} placeholder="🔍 Search employees..." value={search} onChange={e => setSearch(e.target.value)} />
        {["All", "Active", "Resigned"].map(f => (
          <button key={f} onClick={() => setFilterStatus(f)} style={{ ...S.btn, padding: "10px 18px", fontSize: 13, background: filterStatus === f ? "rgba(99,102,241,0.2)" : "rgba(255,255,255,0.04)", color: filterStatus === f ? "#a5b4fc" : "rgba(220,228,240,0.5)", border: `1px solid ${filterStatus === f ? "rgba(99,102,241,0.4)" : "rgba(255,255,255,0.08)"}` }}>{f}</button>
        ))}
      </div>

      <div style={{ ...S.card, padding: 0, overflow: "hidden" }}>
        <table style={{ width: "100%", borderCollapse: "collapse" }}>
          <thead>
            <tr style={{ borderBottom: "1px solid rgba(99,179,237,0.1)" }}>
              {["Employee", "Department", "Role", "Projects", "Status", "Actions"].map(h => (
                <th key={h} style={{ padding: "14px 20px", textAlign: "left", fontSize: 12, fontWeight: 600, color: "rgba(220,228,240,0.4)", letterSpacing: 0.5 }}>{h.toUpperCase()}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {filtered.map(emp => (
              <tr key={emp.id} style={{ borderBottom: "1px solid rgba(99,179,237,0.06)", transition: "background 0.15s" }} onMouseEnter={e => e.currentTarget.style.background = "rgba(255,255,255,0.02)"} onMouseLeave={e => e.currentTarget.style.background = "transparent"}>
                <td style={{ padding: "14px 20px" }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                    <div style={{ width: 36, height: 36, borderRadius: 10, background: `hsl(${emp.name.charCodeAt(0) * 10 % 360},60%,35%)`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 13, fontWeight: 700, color: "white", flexShrink: 0 }}>{emp.avatar.slice(0, 2)}</div>
                    <div>
                      <div style={{ fontSize: 14, fontWeight: 600, color: "white", display: "flex", gap: 6, alignItems: "center" }}>
                        {emp.name} {emp.critical && <span style={{ ...S.badge("#ef4444"), fontSize: 9 }}>⚠ Critical</span>}
                      </div>
                      <div style={{ fontSize: 12, color: "rgba(220,228,240,0.4)" }}>{emp.email}</div>
                    </div>
                  </div>
                </td>
                <td style={{ padding: "14px 20px", fontSize: 13, color: "rgba(220,228,240,0.7)" }}>{emp.department}</td>
                <td style={{ padding: "14px 20px" }}><span style={S.badge("#3b82f6")}>{emp.role}</span></td>
                <td style={{ padding: "14px 20px", fontSize: 13, color: "rgba(220,228,240,0.6)" }}>{emp.projects.length} project(s)</td>
                <td style={{ padding: "14px 20px" }}>
                  <span style={S.badge(emp.status === "Active" ? "#10b981" : "#ef4444")}>
                    {emp.status === "Active" ? "● Active" : "✗ Resigned"}
                  </span>
                </td>
                <td style={{ padding: "14px 20px" }}>
                  {emp.status === "Active" ? (
                    <button onClick={() => setShowResign(emp)} style={{ ...S.btn, background: "rgba(239,68,68,0.1)", border: "1px solid rgba(239,68,68,0.3)", color: "#f87171", padding: "7px 14px", fontSize: 12 }}>Mark Resigned</button>
                  ) : (
                    <span style={{ fontSize: 12, color: "rgba(220,228,240,0.3)" }}>Transition active</span>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Resign Modal */}
      {showResign && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.7)", zIndex: 200, display: "flex", alignItems: "center", justifyContent: "center", backdropFilter: "blur(4px)" }}>
          <div style={{ ...S.card, width: 460, border: "1px solid rgba(239,68,68,0.3)" }}>
            <div style={{ fontSize: 18, marginBottom: 6 }}>🚪 Auto Exit Flow</div>
            <h3 style={{ fontFamily: "'Syne',sans-serif", fontWeight: 800, fontSize: 20, color: "white", marginBottom: 8 }}>Mark {showResign.name} as Resigned?</h3>
            <p style={{ fontSize: 13, color: "rgba(220,228,240,0.55)", lineHeight: 1.6, marginBottom: 20 }}>
              This will automatically:<br />
              ✓ Create transition checklist &nbsp;✓ Lock document deletion<br />
              ✓ Notify stakeholders &nbsp;✓ Generate onboarding board
            </p>
            <div style={{ background: "rgba(239,68,68,0.06)", border: "1px solid rgba(239,68,68,0.15)", borderRadius: 12, padding: 16, marginBottom: 20 }}>
              <div style={{ fontSize: 12, fontWeight: 600, color: "#f87171", marginBottom: 12 }}>IMPACTED PROJECTS</div>
              {showResign.projects.length > 0
                ? showResign.projects.map(pid => {
                  const p = INITIAL_PROJECTS.find(pr => pr.id === pid);
                  return p ? <div key={pid} style={{ fontSize: 13, color: "rgba(220,228,240,0.7)", marginBottom: 6 }}>🗂 {p.project_name} — {p.client_name}</div> : null;
                })
                : <div style={{ fontSize: 13, color: "rgba(220,228,240,0.5)" }}>No active projects</div>
              }
            </div>
            <div style={{ marginBottom: 20 }}>
              <label style={{ fontSize: 12, fontWeight: 600, color: "rgba(220,228,240,0.6)", display: "block", marginBottom: 8 }}>ASSIGN SUCCESSOR</label>
              <select value={successor} onChange={e => setSuccessor(e.target.value)} style={{ ...S.input, width: "100%", padding: "11px 14px", fontSize: 14 }}>
                <option value="">Select successor...</option>
                {employees.filter(e => e.id !== showResign.id && e.status === "Active").map(e => (
                  <option key={e.id} value={e.id}>{e.name} — {e.department}</option>
                ))}
              </select>
            </div>
            <div style={{ display: "flex", gap: 12 }}>
              <button onClick={() => setShowResign(null)} style={{ ...S.btn, flex: 1, padding: 12, background: "rgba(255,255,255,0.06)", color: "rgba(220,228,240,0.6)", border: "1px solid rgba(255,255,255,0.1)" }}>Cancel</button>
              <button onClick={() => handleResign(showResign)} style={{ ...S.btn, flex: 2, padding: 12, background: "linear-gradient(135deg,#ef4444,#dc2626)", color: "white", fontSize: 14 }}>⚡ Confirm & Auto-Start Transition</button>
            </div>
          </div>
        </div>
      )}

      {/* Add Employee Modal */}
      {showAdd && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.7)", zIndex: 200, display: "flex", alignItems: "center", justifyContent: "center", backdropFilter: "blur(4px)" }}>
          <div style={{ ...S.card, width: 420, border: "1px solid rgba(99,102,241,0.3)" }}>
            <h3 style={{ fontFamily: "'Syne',sans-serif", fontWeight: 800, fontSize: 20, color: "white", marginBottom: 20 }}>+ Add New Employee</h3>
            <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
              {[["Full Name", "name", "text"], ["Email", "email", "email"], ["Department", "department", "text"]].map(([l, k, t]) => (
                <div key={k}>
                  <label style={{ fontSize: 12, fontWeight: 600, color: "rgba(220,228,240,0.5)", display: "block", marginBottom: 6 }}>{l.toUpperCase()}</label>
                  <input type={t} style={{ ...S.input, width: "100%", padding: "11px 14px", fontSize: 14, boxSizing: "border-box" }} placeholder={l} value={newEmp[k]} onChange={e => setNewEmp({ ...newEmp, [k]: e.target.value })} />
                </div>
              ))}
              <div>
                <label style={{ fontSize: 12, fontWeight: 600, color: "rgba(220,228,240,0.5)", display: "block", marginBottom: 6 }}>ROLE</label>
                <select value={newEmp.role} onChange={e => setNewEmp({ ...newEmp, role: e.target.value })} style={{ ...S.input, width: "100%", padding: "11px 14px", fontSize: 14 }}>
                  <option>Employee</option><option>HR</option><option>Admin</option>
                </select>
              </div>
            </div>
            <div style={{ display: "flex", gap: 12, marginTop: 24 }}>
              <button onClick={() => setShowAdd(false)} style={{ ...S.btn, flex: 1, padding: 12, background: "rgba(255,255,255,0.06)", color: "rgba(220,228,240,0.6)", border: "1px solid rgba(255,255,255,0.1)" }}>Cancel</button>
              <button onClick={handleAdd} style={{ ...S.btn, flex: 2, padding: 12, background: "linear-gradient(135deg,#3b82f6,#8b5cf6)", color: "white" }}>Add Employee</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── SOP VAULT PAGE ───────────────────────────────────────────────────────────
function SOPVaultPage({ sops, setSops, employees, auditLogs, setAuditLogs }) {
  const [search, setSearch] = useState("");
  const [showAdd, setShowAdd] = useState(false);
  const [newSop, setNewSop] = useState({ title: "", description: "", tags: "", version: "v1.0", coverage: 80 });
  const [selected, setSelected] = useState(null);

  const filtered = sops.filter(s => s.title.toLowerCase().includes(search.toLowerCase()) || s.tags.join(" ").includes(search.toLowerCase()));

  const handleAdd = () => {
    if (!newSop.title) return;
    const s = { ...newSop, id: "s" + Date.now(), file_url: "#", project_id: null, created_by: "e3", tags: newSop.tags.split(",").map(t => t.trim()).filter(Boolean), created_at: new Date().toISOString().split("T")[0], coverage: Number(newSop.coverage) };
    setSops(prev => [...prev, s]);
    setAuditLogs(prev => [...prev, { id: "a" + Date.now(), action: `SOP uploaded: ${newSop.title}`, performed_by: "Priya Kapoor", timestamp: new Date(), type: "sop" }]);
    setNewSop({ title: "", description: "", tags: "", version: "v1.0", coverage: 80 });
    setShowAdd(false);
  };

  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", marginBottom: 24 }}>
        <div>
          <h1 style={{ fontFamily: "'Syne',sans-serif", fontWeight: 800, fontSize: 26, color: "white", letterSpacing: "-0.5px" }}>SOP Vault</h1>
          <p style={{ color: "rgba(220,228,240,0.45)", fontSize: 14 }}>{sops.length} documents · {Math.round(sops.reduce((s, x) => s + x.coverage, 0) / (sops.length || 1))}% avg coverage</p>
        </div>
        <button onClick={() => setShowAdd(true)} style={{ ...S.btn, background: "linear-gradient(135deg,#3b82f6,#8b5cf6)", color: "white", padding: "11px 22px", fontSize: 14 }}>+ Upload SOP</button>
      </div>

      <input style={{ ...S.input, width: "100%", padding: "12px 18px", fontSize: 14, marginBottom: 20, boxSizing: "border-box" }} placeholder="🔍 Search SOPs by title or tag..." value={search} onChange={e => setSearch(e.target.value)} />

      <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 18 }}>
        {filtered.map(sop => (
          <div key={sop.id} onClick={() => setSelected(sop)} style={{ ...S.card, cursor: "pointer", transition: "all 0.2s", borderColor: selected?.id === sop.id ? "rgba(99,102,241,0.5)" : "rgba(99,179,237,0.1)" }} onMouseEnter={e => e.currentTarget.style.transform = "translateY(-4px)"} onMouseLeave={e => e.currentTarget.style.transform = "translateY(0)"}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 12 }}>
              <div style={{ fontSize: 28 }}>📄</div>
              <span style={{ ...S.badge(sop.coverage >= 80 ? "#10b981" : sop.coverage >= 60 ? "#f59e0b" : "#ef4444"), fontSize: 11 }}>{sop.coverage}% covered</span>
            </div>
            <h3 style={{ fontSize: 15, fontWeight: 700, color: "white", marginBottom: 6 }}>{sop.title}</h3>
            <p style={{ fontSize: 12, color: "rgba(220,228,240,0.5)", lineHeight: 1.5, marginBottom: 14 }}>{sop.description.slice(0, 90)}...</p>
            <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginBottom: 14 }}>
              {sop.tags.map(t => <span key={t} style={S.tag}>{t}</span>)}
            </div>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <span style={{ fontSize: 11, color: "rgba(220,228,240,0.4)" }}>{sop.version} · {sop.created_at}</span>
              <div style={{ width: 60, height: 4, background: "rgba(255,255,255,0.1)", borderRadius: 2 }}>
                <div style={{ width: sop.coverage + "%", height: 4, background: sop.coverage >= 80 ? "#10b981" : sop.coverage >= 60 ? "#f59e0b" : "#ef4444", borderRadius: 2 }} />
              </div>
            </div>
          </div>
        ))}
      </div>

      {selected && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.7)", zIndex: 200, display: "flex", alignItems: "center", justifyContent: "center", backdropFilter: "blur(4px)" }} onClick={() => setSelected(null)}>
          <div style={{ ...S.card, width: 520, border: "1px solid rgba(99,102,241,0.3)" }} onClick={e => e.stopPropagation()}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 20 }}>
              <div>
                <div style={{ ...S.badge("#3b82f6"), marginBottom: 10 }}>✨ AI Assisted</div>
                <h3 style={{ fontFamily: "'Syne',sans-serif", fontWeight: 800, fontSize: 22, color: "white" }}>{selected.title}</h3>
              </div>
              <button onClick={() => setSelected(null)} style={{ ...S.btn, padding: "6px 12px", background: "rgba(255,255,255,0.06)", color: "rgba(220,228,240,0.5)", border: "1px solid rgba(255,255,255,0.1)" }}>✕</button>
            </div>
            <div style={{ background: "rgba(99,102,241,0.06)", border: "1px solid rgba(99,102,241,0.15)", borderRadius: 12, padding: 16, marginBottom: 16 }}>
              <div style={{ fontSize: 12, fontWeight: 600, color: "#a5b4fc", marginBottom: 8 }}>🤖 AI SUMMARY</div>
              <p style={{ fontSize: 13, color: "rgba(220,228,240,0.75)", lineHeight: 1.6 }}>{selected.description}</p>
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 12, marginBottom: 16 }}>
              {[["Version", selected.version], ["Coverage", selected.coverage + "%"], ["Created", selected.created_at]].map(([l, v]) => (
                <div key={l} style={{ background: "rgba(255,255,255,0.04)", borderRadius: 10, padding: 12, textAlign: "center" }}>
                  <div style={{ fontSize: 11, color: "rgba(220,228,240,0.4)", marginBottom: 4 }}>{l}</div>
                  <div style={{ fontSize: 15, fontWeight: 700, color: "white" }}>{v}</div>
                </div>
              ))}
            </div>
            <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
              {selected.tags.map(t => <span key={t} style={S.tag}>{t}</span>)}
            </div>
          </div>
        </div>
      )}

      {showAdd && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.7)", zIndex: 200, display: "flex", alignItems: "center", justifyContent: "center", backdropFilter: "blur(4px)" }}>
          <div style={{ ...S.card, width: 460, border: "1px solid rgba(99,102,241,0.3)" }}>
            <h3 style={{ fontFamily: "'Syne',sans-serif", fontWeight: 800, fontSize: 20, color: "white", marginBottom: 20 }}>📁 Upload New SOP</h3>
            <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
              {[["SOP Title", "title", "text"], ["Tags (comma separated)", "tags", "text"], ["Version", "version", "text"]].map(([l, k, t]) => (
                <div key={k}>
                  <label style={{ fontSize: 12, fontWeight: 600, color: "rgba(220,228,240,0.5)", display: "block", marginBottom: 6 }}>{l.toUpperCase()}</label>
                  <input type={t} style={{ ...S.input, width: "100%", padding: "11px 14px", fontSize: 14, boxSizing: "border-box" }} placeholder={l} value={newSop[k]} onChange={e => setNewSop({ ...newSop, [k]: e.target.value })} />
                </div>
              ))}
              <div>
                <label style={{ fontSize: 12, fontWeight: 600, color: "rgba(220,228,240,0.5)", display: "block", marginBottom: 6 }}>DESCRIPTION</label>
                <textarea style={{ ...S.input, width: "100%", padding: "11px 14px", fontSize: 14, boxSizing: "border-box", resize: "vertical", minHeight: 80 }} placeholder="SOP description..." value={newSop.description} onChange={e => setNewSop({ ...newSop, description: e.target.value })} />
              </div>
              <div style={{ border: "2px dashed rgba(99,179,237,0.2)", borderRadius: 12, padding: 24, textAlign: "center", color: "rgba(220,228,240,0.4)", fontSize: 13 }}>
                📎 Drag & drop file here or <span style={{ color: "#93c5fd", cursor: "pointer" }}>browse</span>
              </div>
            </div>
            <div style={{ display: "flex", gap: 12, marginTop: 20 }}>
              <button onClick={() => setShowAdd(false)} style={{ ...S.btn, flex: 1, padding: 12, background: "rgba(255,255,255,0.06)", color: "rgba(220,228,240,0.6)", border: "1px solid rgba(255,255,255,0.1)" }}>Cancel</button>
              <button onClick={handleAdd} style={{ ...S.btn, flex: 2, padding: 12, background: "linear-gradient(135deg,#3b82f6,#8b5cf6)", color: "white" }}>Upload SOP</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── TRANSITIONS PAGE ─────────────────────────────────────────────────────────
function TransitionsPage({ transitions, setTransitions, employees }) {
  if (transitions.length === 0) return (
    <div>
      <h1 style={{ fontFamily: "'Syne',sans-serif", fontWeight: 800, fontSize: 26, color: "white", letterSpacing: "-0.5px", marginBottom: 8 }}>Transitions</h1>
      <div style={{ ...S.card, textAlign: "center", padding: 60 }}>
        <div style={{ fontSize: 48, marginBottom: 16 }}>✅</div>
        <div style={{ fontFamily: "'Syne',sans-serif", fontWeight: 700, fontSize: 20, color: "white", marginBottom: 8 }}>No Active Transitions</div>
        <p style={{ color: "rgba(220,228,240,0.45)", fontSize: 14 }}>All employees are active. When someone resigns, their transition will appear here.</p>
      </div>
    </div>
  );

  const updateChecklist = (tid, field) => {
    setTransitions(prev => prev.map(t => t.id === tid ? { ...t, [field]: t[field] === "Complete" ? "In Progress" : "Complete" } : t));
  };

  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", marginBottom: 24 }}>
        <div>
          <h1 style={{ fontFamily: "'Syne',sans-serif", fontWeight: 800, fontSize: 26, color: "white", letterSpacing: "-0.5px" }}>Transitions</h1>
          <p style={{ color: "rgba(220,228,240,0.45)", fontSize: 14 }}>{transitions.length} active transition(s)</p>
        </div>
        <span style={{ ...S.badge("#ef4444"), fontSize: 13, padding: "6px 14px" }}>🔴 LIVE — Action Required</span>
      </div>

      {transitions.map(t => {
        const exiting = employees.find(e => e.id === t.exiting_employee_id);
        const successor = employees.find(e => e.id === t.successor_id);
        const steps = [
          { label: "Transition record created", done: true, icon: "✓" },
          { label: "Notification sent to stakeholders", done: true, icon: "✓" },
          { label: "Document access locked", done: true, icon: "✓" },
          { label: "SOP completion prompted", done: t.checklist_status === "Complete", icon: t.checklist_status === "Complete" ? "✓" : "○" },
          { label: "Knowledge transfer verified", done: t.knowledge_transfer_status === "Complete", icon: t.knowledge_transfer_status === "Complete" ? "✓" : "○" },
          { label: "Successor onboarding activated", done: t.knowledge_transfer_status === "Complete", icon: t.knowledge_transfer_status === "Complete" ? "✓" : "○" },
        ];
        const doneCount = steps.filter(s => s.done).length;
        const progress = Math.round((doneCount / steps.length) * 100);

        return (
          <div key={t.id} style={{ ...S.card, marginBottom: 20, borderColor: "rgba(239,68,68,0.25)" }}>
            <div style={{ display: "flex", gap: 20, alignItems: "flex-start", marginBottom: 24 }}>
              <div style={{ flex: 1 }}>
                <div style={{ display: "flex", gap: 10, alignItems: "center", marginBottom: 12 }}>
                  <span style={{ fontFamily: "'Syne',sans-serif", fontWeight: 800, fontSize: 18, color: "white" }}>Auto Exit Flow — {t.exiting_name}</span>
                  <span style={{ ...S.badge("#ef4444") }}>In Progress</span>
                </div>
                <div style={{ display: "flex", gap: 24 }}>
                  <div style={{ ...S.cardSm, flex: 1, borderColor: "rgba(239,68,68,0.2)" }}>
                    <div style={{ fontSize: 11, color: "rgba(220,228,240,0.4)", marginBottom: 6 }}>EXITING EMPLOYEE</div>
                    <div style={{ fontSize: 16, fontWeight: 700, color: "#f87171" }}>🚪 {t.exiting_name}</div>
                    <div style={{ fontSize: 12, color: "rgba(220,228,240,0.5)", marginTop: 2 }}>{t.department}</div>
                  </div>
                  <div style={{ display: "flex", alignItems: "center", fontSize: 24, color: "rgba(220,228,240,0.3)" }}>→</div>
                  <div style={{ ...S.cardSm, flex: 1, borderColor: "rgba(16,185,129,0.2)" }}>
                    <div style={{ fontSize: 11, color: "rgba(220,228,240,0.4)", marginBottom: 6 }}>SUCCESSOR</div>
                    <div style={{ fontSize: 16, fontWeight: 700, color: "#34d399" }}>🎯 {t.successor_name}</div>
                    <div style={{ fontSize: 12, color: "rgba(220,228,240,0.5)", marginTop: 2 }}>Assigned {timeAgo(t.created_at)}</div>
                  </div>
                </div>
              </div>
              <div style={{ textAlign: "center", minWidth: 90 }}>
                <div style={{ fontFamily: "'Syne',sans-serif", fontWeight: 800, fontSize: 36, color: progress === 100 ? "#10b981" : "#f59e0b" }}>{progress}%</div>
                <div style={{ fontSize: 11, color: "rgba(220,228,240,0.4)" }}>complete</div>
              </div>
            </div>

            <div style={{ background: "rgba(255,255,255,0.05)", borderRadius: 6, height: 6, marginBottom: 20 }}>
              <div style={{ width: progress + "%", height: 6, background: "linear-gradient(90deg,#3b82f6,#8b5cf6)", borderRadius: 6, transition: "width 0.8s ease" }} />
            </div>

            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
              {steps.map((step, i) => (
                <div key={i} style={{ display: "flex", alignItems: "center", gap: 10, padding: "10px 14px", background: step.done ? "rgba(16,185,129,0.08)" : "rgba(255,255,255,0.03)", borderRadius: 10, border: `1px solid ${step.done ? "rgba(16,185,129,0.2)" : "rgba(255,255,255,0.07)"}` }}>
                  <span style={{ fontSize: 16, color: step.done ? "#10b981" : "rgba(220,228,240,0.3)" }}>{step.done ? "✓" : "○"}</span>
                  <span style={{ fontSize: 13, color: step.done ? "rgba(220,228,240,0.8)" : "rgba(220,228,240,0.4)" }}>{step.label}</span>
                </div>
              ))}
            </div>

            <div style={{ display: "flex", gap: 12, marginTop: 20 }}>
              <button onClick={() => updateChecklist(t.id, "checklist_status")} style={{ ...S.btn, flex: 1, padding: "11px", background: t.checklist_status === "Complete" ? "rgba(16,185,129,0.15)" : "rgba(99,102,241,0.15)", border: `1px solid ${t.checklist_status === "Complete" ? "rgba(16,185,129,0.3)" : "rgba(99,102,241,0.3)"}`, color: t.checklist_status === "Complete" ? "#34d399" : "#a5b4fc", fontSize: 13 }}>
                {t.checklist_status === "Complete" ? "✓ SOP Checklist Complete" : "Complete SOP Checklist"}
              </button>
              <button onClick={() => updateChecklist(t.id, "knowledge_transfer_status")} style={{ ...S.btn, flex: 1, padding: "11px", background: t.knowledge_transfer_status === "Complete" ? "rgba(16,185,129,0.15)" : "rgba(99,102,241,0.15)", border: `1px solid ${t.knowledge_transfer_status === "Complete" ? "rgba(16,185,129,0.3)" : "rgba(99,102,241,0.3)"}`, color: t.knowledge_transfer_status === "Complete" ? "#34d399" : "#a5b4fc", fontSize: 13 }}>
                {t.knowledge_transfer_status === "Complete" ? "✓ Knowledge Transferred" : "Verify Knowledge Transfer"}
              </button>
            </div>

            {/* Successor Onboarding Board */}
            {t.successor_id && (
              <div style={{ marginTop: 20, background: "rgba(99,102,241,0.06)", border: "1px solid rgba(99,102,241,0.2)", borderRadius: 14, padding: 18 }}>
                <div style={{ fontSize: 13, fontWeight: 700, color: "#a5b4fc", marginBottom: 14 }}>🎯 {t.successor_name}'s Onboarding Board</div>
                <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 12 }}>
                  {[["📘 Role Guide", "Ready", "#10b981"], ["📁 SOPs Access", "Granted", "#10b981"], ["📊 KPI Dashboard", "Generating...", "#f59e0b"], ["📅 Pending Tasks", "3 tasks", "#3b82f6"]].map(([l, v, c]) => (
                    <div key={l} style={{ background: "rgba(255,255,255,0.03)", borderRadius: 10, padding: 12, textAlign: "center" }}>
                      <div style={{ fontSize: 12, color: "rgba(220,228,240,0.5)", marginBottom: 6 }}>{l}</div>
                      <div style={{ fontSize: 13, fontWeight: 600, color: c }}>{v}</div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}

// ─── ANALYTICS PAGE ───────────────────────────────────────────────────────────
function AnalyticsPage({ employees, sops, transitions }) {
  const resigned = employees.filter(e => e.status === "Resigned").length;
  const active = employees.filter(e => e.status === "Active").length;
  const avgCoverage = Math.round(sops.reduce((s, x) => s + x.coverage, 0) / (sops.length || 1));
  const riskScore = resigned > 0 && avgCoverage < 80 ? 72 : resigned > 0 ? 45 : 20;

  const bars = [
    { dept: "Operations", sop: sops[0]?.coverage || 75, risk: resigned > 0 ? 85 : 30 },
    { dept: "Engineering", sop: 88, risk: 20 },
    { dept: "Sales", sop: 55, risk: 60 },
    { dept: "HR", sop: 95, risk: 15 },
  ];

  return (
    <div>
      <h1 style={{ fontFamily: "'Syne',sans-serif", fontWeight: 800, fontSize: 26, color: "white", letterSpacing: "-0.5px", marginBottom: 8 }}>Analytics</h1>
      <p style={{ color: "rgba(220,228,240,0.45)", fontSize: 14, marginBottom: 28 }}>Knowledge health metrics across your organization</p>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 18, marginBottom: 24 }}>
        {[["Knowledge Risk Score™", riskScore + "/100", riskScore > 60 ? "#ef4444" : riskScore > 40 ? "#f59e0b" : "#10b981"], ["SOP Coverage", avgCoverage + "%", "#3b82f6"], ["Transition Health", transitions.length > 0 ? "Needs Attention" : "Excellent", transitions.length > 0 ? "#f59e0b" : "#10b981"]].map(([l, v, c]) => (
          <div key={l} style={{ ...S.card, textAlign: "center" }}>
            <div style={{ fontFamily: "'Syne',sans-serif", fontWeight: 800, fontSize: 38, color: c, marginBottom: 8 }}>{v}</div>
            <div style={{ fontSize: 14, color: "rgba(220,228,240,0.55)" }}>{l}</div>
          </div>
        ))}
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20 }}>
        <div style={S.card}>
          <div style={{ fontSize: 15, fontWeight: 700, color: "white", marginBottom: 20 }}>📊 SOP Coverage by Department</div>
          {bars.map(b => (
            <div key={b.dept} style={{ marginBottom: 16 }}>
              <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
                <span style={{ fontSize: 13, color: "rgba(220,228,240,0.7)" }}>{b.dept}</span>
                <span style={{ fontSize: 13, fontWeight: 600, color: b.sop >= 80 ? "#10b981" : "#f59e0b" }}>{b.sop}%</span>
              </div>
              <div style={{ background: "rgba(255,255,255,0.07)", borderRadius: 4, height: 8 }}>
                <div style={{ width: b.sop + "%", height: 8, background: b.sop >= 80 ? "linear-gradient(90deg,#10b981,#34d399)" : "linear-gradient(90deg,#f59e0b,#fbbf24)", borderRadius: 4, transition: "width 1s ease" }} />
              </div>
            </div>
          ))}
        </div>

        <div style={S.card}>
          <div style={{ fontSize: 15, fontWeight: 700, color: "white", marginBottom: 20 }}>🔴 Risk Score by Department</div>
          {bars.map(b => (
            <div key={b.dept} style={{ marginBottom: 16 }}>
              <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
                <span style={{ fontSize: 13, color: "rgba(220,228,240,0.7)" }}>{b.dept}</span>
                <span style={{ fontSize: 13, fontWeight: 600, color: b.risk > 60 ? "#ef4444" : b.risk > 40 ? "#f59e0b" : "#10b981" }}>{b.risk}/100</span>
              </div>
              <div style={{ background: "rgba(255,255,255,0.07)", borderRadius: 4, height: 8 }}>
                <div style={{ width: b.risk + "%", height: 8, background: b.risk > 60 ? "linear-gradient(90deg,#ef4444,#f87171)" : b.risk > 40 ? "linear-gradient(90deg,#f59e0b,#fbbf24)" : "linear-gradient(90deg,#10b981,#34d399)", borderRadius: 4, transition: "width 1s ease" }} />
              </div>
            </div>
          ))}
        </div>
      </div>

      <div style={{ ...S.card, marginTop: 20 }}>
        <div style={{ fontSize: 15, fontWeight: 700, color: "white", marginBottom: 18 }}>📈 Team Overview</div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(5,1fr)", gap: 16 }}>
          {[["Total", employees.length, "#dce4f0"], ["Active", active, "#10b981"], ["Resigned", resigned, "#ef4444"], ["SOPs", sops.length, "#3b82f6"], ["Transitions", transitions.length, "#f59e0b"]].map(([l, v, c]) => (
            <div key={l} style={{ background: "rgba(255,255,255,0.03)", borderRadius: 12, padding: 18, textAlign: "center" }}>
              <div style={{ fontFamily: "'Syne',sans-serif", fontWeight: 800, fontSize: 30, color: c }}>{v}</div>
              <div style={{ fontSize: 12, color: "rgba(220,228,240,0.45)", marginTop: 4 }}>{l}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── AI PAGE ─────────────────────────────────────────────────────────────────
function AIPage({ employees, sops, transitions }) {
  const [messages, setMessages] = useState([
    { role: "ai", text: "👋 Hi! I'm Knowva AI. Ask me about knowledge risk, SOP coverage, transition health, or anything about your org. Try the quick prompts below!", time: new Date() },
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const bottomRef = useRef(null);

  const QUICK = [
    "Show knowledge risk by department",
    "Summarize all SOPs",
    "Show resignation trends",
    "Which employees are critical?",
  ];

  const respond = (query) => {
    const q = query.toLowerCase();
    if (q.includes("risk") || q.includes("department")) return AI_RESPONSES.risk(employees, sops, transitions);
    if (q.includes("sop") || q.includes("summar")) return AI_RESPONSES.sop(sops);
    if (q.includes("trend") || q.includes("resign")) return AI_RESPONSES.trend(employees);
    if (q.includes("critical")) {
      const critical = employees.filter(e => e.critical || e.projects.length >= 2);
      return `⚠️ **Critical Knowledge Holders**\n\n${critical.map(e => `• **${e.name}** (${e.department}) — ${e.projects.length} project(s), status: ${e.status}`).join("\n")}\n\n${critical.some(e => e.status === "Resigned") ? "🔴 URGENT: A critical holder has resigned! Review transition status immediately." : "✅ All critical employees are currently active."}`;
    }
    return `I analyzed your query about "${query}".\n\nBased on NovaTech's current data:\n• ${employees.filter(e => e.status === "Active").length} active employees\n• ${sops.length} SOPs in vault (${Math.round(sops.reduce((s, x) => s + x.coverage, 0) / (sops.length || 1))}% avg coverage)\n• ${transitions.length} active transition(s)\n\nTry asking me: "Show risk by department" or "Summarize SOPs"`;
  };

  const send = (query) => {
    const q = query || input;
    if (!q.trim()) return;
    setMessages(prev => [...prev, { role: "user", text: q, time: new Date() }]);
    setInput("");
    setLoading(true);
    setTimeout(() => {
      setMessages(prev => [...prev, { role: "ai", text: respond(q), time: new Date() }]);
      setLoading(false);
    }, 800);
  };

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages]);

  return (
    <div style={{ height: "calc(100vh - 120px)", display: "flex", flexDirection: "column" }}>
      <div style={{ marginBottom: 20 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 14, marginBottom: 6 }}>
          <div style={{ width: 40, height: 40, borderRadius: 13, background: "linear-gradient(135deg,#8b5cf6,#3b82f6)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 20 }}>✨</div>
          <div>
            <h1 style={{ fontFamily: "'Syne',sans-serif", fontWeight: 800, fontSize: 22, color: "white" }}>Ask Knowva AI</h1>
            <div style={{ fontSize: 12, color: "#10b981" }}>● Live · Analyzing NovaTech data</div>
          </div>
        </div>
      </div>

      <div style={{ display: "flex", gap: 10, marginBottom: 16, flexWrap: "wrap" }}>
        {QUICK.map(q => (
          <button key={q} onClick={() => send(q)} style={{ ...S.btn, padding: "8px 14px", background: "rgba(99,102,241,0.1)", border: "1px solid rgba(99,102,241,0.25)", color: "#a5b4fc", fontSize: 12 }}>{q}</button>
        ))}
      </div>

      <div style={{ flex: 1, overflowY: "auto", display: "flex", flexDirection: "column", gap: 14, paddingRight: 4 }}>
        {messages.map((msg, i) => (
          <div key={i} style={{ display: "flex", justifyContent: msg.role === "user" ? "flex-end" : "flex-start" }}>
            <div style={{ maxWidth: "75%", padding: "14px 18px", borderRadius: msg.role === "user" ? "18px 18px 4px 18px" : "18px 18px 18px 4px", background: msg.role === "user" ? "linear-gradient(135deg,rgba(99,102,241,0.4),rgba(59,130,246,0.3))" : "rgba(255,255,255,0.05)", border: `1px solid ${msg.role === "user" ? "rgba(99,102,241,0.3)" : "rgba(255,255,255,0.08)"}`, fontSize: 14, color: "#dce4f0", lineHeight: 1.65, whiteSpace: "pre-line" }}>
              {msg.text}
              <div style={{ fontSize: 10, color: "rgba(220,228,240,0.3)", marginTop: 8, textAlign: msg.role === "user" ? "right" : "left" }}>{timeAgo(msg.time)}</div>
            </div>
          </div>
        ))}
        {loading && (
          <div style={{ display: "flex" }}>
            <div style={{ padding: "14px 18px", borderRadius: "18px 18px 18px 4px", background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.08)", fontSize: 13, color: "rgba(220,228,240,0.5)" }}>
              ✨ Analyzing...
            </div>
          </div>
        )}
        <div ref={bottomRef} />
      </div>

      <div style={{ display: "flex", gap: 12, marginTop: 16 }}>
        <input style={{ ...S.input, flex: 1, padding: "14px 18px", fontSize: 14 }} placeholder="Ask anything about your org's knowledge..." value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => e.key === "Enter" && send()} />
        <button onClick={() => send()} style={{ ...S.btn, background: "linear-gradient(135deg,#3b82f6,#8b5cf6)", color: "white", padding: "14px 22px", fontSize: 18 }}>↑</button>
      </div>
    </div>
  );
}

// ─── BILLING PAGE ─────────────────────────────────────────────────────────────
function BillingPage({ company }) {
  const days = daysLeft(company.trial_end_date);
  const plans = [
    { name: "Starter", price: "₹149", per: "/employee/mo", color: "#3b82f6", features: ["20 employees", "SOP Vault", "Auto Exit Flow", "Basic Analytics"] },
    { name: "Growth", price: "₹249", per: "/employee/mo", color: "#8b5cf6", features: ["200 employees", "AI Knowledge Vault", "Risk Score™", "Priority Support", "Ask Knowva AI"], popular: true },
    { name: "Enterprise", price: "Custom", per: "", color: "#10b981", features: ["Unlimited employees", "Custom integrations", "Dedicated CSM", "SLA guarantee", "SSO & SCIM"] },
  ];
  return (
    <div>
      <h1 style={{ fontFamily: "'Syne',sans-serif", fontWeight: 800, fontSize: 26, color: "white", letterSpacing: "-0.5px", marginBottom: 8 }}>Billing</h1>
      <div style={{ ...S.card, marginBottom: 24, background: "rgba(251,191,36,0.06)", borderColor: "rgba(251,191,36,0.25)", display: "flex", alignItems: "center", gap: 20 }}>
        <div style={{ fontSize: 36 }}>⏰</div>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 16, fontWeight: 700, color: "#fbbf24", marginBottom: 4 }}>Free Trial — {days} days remaining</div>
          <div style={{ fontSize: 13, color: "rgba(220,228,240,0.55)" }}>You have full access to all features. Upgrade before your trial ends to keep your data.</div>
          <div style={{ background: "rgba(255,255,255,0.08)", borderRadius: 4, height: 6, marginTop: 12, maxWidth: 300 }}>
            <div style={{ background: "linear-gradient(90deg,#fbbf24,#f59e0b)", height: 6, borderRadius: 4, width: `${(days / 30) * 100}%` }} />
          </div>
        </div>
        <div style={{ textAlign: "center" }}>
          <div style={{ fontFamily: "'Syne',sans-serif", fontWeight: 800, fontSize: 40, color: "#fbbf24" }}>{days}</div>
          <div style={{ fontSize: 12, color: "rgba(220,228,240,0.4)" }}>days left</div>
        </div>
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 20 }}>
        {plans.map(p => (
          <div key={p.name} style={{ ...S.card, borderColor: p.popular ? "rgba(139,92,246,0.4)" : "rgba(99,179,237,0.1)", background: p.popular ? "rgba(139,92,246,0.06)" : "#0f1826", position: "relative" }}>
            {p.popular && <div style={{ position: "absolute", top: -12, left: "50%", transform: "translateX(-50%)", background: "linear-gradient(135deg,#8b5cf6,#3b82f6)", borderRadius: 100, padding: "4px 16px", fontSize: 11, fontWeight: 700, color: "white", whiteSpace: "nowrap" }}>🔥 Most Popular</div>}
            <div style={{ fontFamily: "'Syne',sans-serif", fontWeight: 800, fontSize: 22, color: "white", marginBottom: 4 }}>{p.name}</div>
            <div style={{ display: "flex", alignItems: "flex-end", gap: 4, marginBottom: 20 }}>
              <span style={{ fontFamily: "'Syne',sans-serif", fontWeight: 800, fontSize: 36, color: p.color }}>{p.price}</span>
              <span style={{ fontSize: 13, color: "rgba(220,228,240,0.4)", paddingBottom: 6 }}>{p.per}</span>
            </div>
            {p.features.map(f => <div key={f} style={{ display: "flex", gap: 10, fontSize: 13, color: "rgba(220,228,240,0.7)", marginBottom: 10, alignItems: "center" }}><span style={{ color: "#10b981", fontSize: 12 }}>✓</span>{f}</div>)}
            <button style={{ ...S.btn, width: "100%", padding: 12, marginTop: 16, background: p.popular ? "linear-gradient(135deg,#8b5cf6,#3b82f6)" : "rgba(255,255,255,0.06)", color: p.popular ? "white" : "rgba(220,228,240,0.7)", border: p.popular ? "none" : "1px solid rgba(255,255,255,0.1)", fontSize: 14 }}>
              {p.name === "Enterprise" ? "Talk to Sales" : "Upgrade to " + p.name}
            </button>
          </div>
        ))}
      </div>
      <div style={{ ...S.card, marginTop: 20, display: "flex", gap: 16, flexWrap: "wrap" }}>
        {["🔒 256-bit encryption", "🏢 Multi-tenant isolation", "📋 GDPR compliant", "🔄 Cancel anytime", "💾 Data never deleted"].map(t => (
          <span key={t} style={{ fontSize: 13, color: "rgba(220,228,240,0.5)" }}>{t}</span>
        ))}
      </div>
    </div>
  );
}

// ─── MAIN APP ─────────────────────────────────────────────────────────────────
export default function KnowvaApp() {
  const [user, setUser] = useState(null);
  const [page, setPage] = useState("dashboard");
  const [employees, setEmployees] = useState(INITIAL_EMPLOYEES);
  const [sops, setSops] = useState(INITIAL_SOPS);
  const [transitions, setTransitions] = useState(INITIAL_TRANSITIONS);
  const [auditLogs, setAuditLogs] = useState(AUDIT_LOGS_INIT);
  const [notifOpen, setNotifOpen] = useState(false);

  if (!user) return <AuthScreen onLogin={setUser} />;

  const renderPage = () => {
    switch (page) {
      case "dashboard": return <DashboardPage employees={employees} sops={sops} transitions={transitions} auditLogs={auditLogs} setPage={setPage} />;
      case "employees": return <EmployeesPage employees={employees} setEmployees={setEmployees} transitions={transitions} setTransitions={setTransitions} auditLogs={auditLogs} setAuditLogs={setAuditLogs} />;
      case "sops": return <SOPVaultPage sops={sops} setSops={setSops} employees={employees} auditLogs={auditLogs} setAuditLogs={setAuditLogs} />;
      case "projects": return (
        <div>
          <h1 style={{ fontFamily: "'Syne',sans-serif", fontWeight: 800, fontSize: 26, color: "white", marginBottom: 24 }}>Projects</h1>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 18 }}>
            {INITIAL_PROJECTS.map(p => (
              <div key={p.id} style={S.card}>
                <div style={{ fontFamily: "'Syne',sans-serif", fontWeight: 700, fontSize: 18, color: "white", marginBottom: 8 }}>🗂 {p.project_name}</div>
                <div style={{ fontSize: 13, color: "rgba(220,228,240,0.5)", marginBottom: 16 }}>Client: {p.client_name}</div>
                <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                  {p.assigned_to.map(eid => {
                    const emp = employees.find(e => e.id === eid);
                    return emp ? <span key={eid} style={{ ...S.badge(emp.status === "Active" ? "#10b981" : "#ef4444") }}>{emp.name}</span> : null;
                  })}
                </div>
              </div>
            ))}
          </div>
        </div>
      );
      case "transitions": return <TransitionsPage transitions={transitions} setTransitions={setTransitions} employees={employees} />;
      case "analytics": return <AnalyticsPage employees={employees} sops={sops} transitions={transitions} />;
      case "ai": return <AIPage employees={employees} sops={sops} transitions={transitions} />;
      case "billing": return <BillingPage company={MOCK_COMPANY} />;
      default: return null;
    }
  };

  return (
    <div style={S.app}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&family=Syne:wght@700;800&display=swap');
        * { box-sizing: border-box; }
        select option { background: #0f1826; }
        textarea { resize: vertical; }
        ::-webkit-scrollbar { width: 4px; height: 4px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: rgba(99,102,241,0.3); border-radius: 10px; }
      `}</style>

      <Sidebar active={page} setActive={setPage} company={MOCK_COMPANY} />

      <div style={S.main}>
        <div style={S.topbar}>
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <span style={{ fontSize: 13, color: "rgba(220,228,240,0.4)" }}>NovaTech Solutions</span>
            <span style={{ color: "rgba(220,228,240,0.2)" }}>/</span>
            <span style={{ fontSize: 13, color: "#a5b4fc", fontWeight: 600 }}>{NAV.find(n => n.id === page)?.label}</span>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
            {transitions.length > 0 && (
              <div style={{ ...S.badge("#ef4444"), fontSize: 12, padding: "5px 12px", animation: "none" }}>
                ⚡ {transitions.length} Active Transition
              </div>
            )}
            <button onClick={() => setNotifOpen(!notifOpen)} style={{ ...S.btn, width: 36, height: 36, padding: 0, background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.08)", color: "white", fontSize: 16, display: "flex", alignItems: "center", justifyContent: "center", position: "relative" }}>
              🔔
              {auditLogs.length > 4 && <div style={{ position: "absolute", top: 6, right: 6, width: 8, height: 8, borderRadius: "50%", background: "#ef4444" }} />}
            </button>
            <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
              <div style={{ width: 32, height: 32, borderRadius: 9, background: "linear-gradient(135deg,#8b5cf6,#3b82f6)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 13, fontWeight: 700, color: "white" }}>PK</div>
              <div>
                <div style={{ fontSize: 13, fontWeight: 600, color: "white" }}>{user.name}</div>
                <div style={{ fontSize: 11, color: "rgba(220,228,240,0.4)" }}>{user.role}</div>
              </div>
            </div>
            <button onClick={() => setUser(null)} style={{ ...S.btn, padding: "7px 14px", background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)", color: "rgba(220,228,240,0.5)", fontSize: 12 }}>Sign Out</button>
          </div>
        </div>

        {notifOpen && (
          <div style={{ position: "fixed", top: 64, right: 20, width: 340, background: "#0f1826", border: "1px solid rgba(99,179,237,0.15)", borderRadius: 16, padding: 20, zIndex: 100, boxShadow: "0 20px 60px rgba(0,0,0,0.5)" }}>
            <div style={{ fontSize: 15, fontWeight: 700, color: "white", marginBottom: 14 }}>🔔 Notifications</div>
            {auditLogs.slice(-5).reverse().map(log => (
              <div key={log.id} style={{ display: "flex", gap: 10, padding: "9px 0", borderBottom: "1px solid rgba(99,179,237,0.06)" }}>
                <div style={{ width: 7, height: 7, borderRadius: "50%", background: log.type === "transition" ? "#ef4444" : "#3b82f6", marginTop: 5, flexShrink: 0 }} />
                <div>
                  <div style={{ fontSize: 13, color: "#dce4f0" }}>{log.action}</div>
                  <div style={{ fontSize: 11, color: "rgba(220,228,240,0.35)" }}>{timeAgo(log.timestamp)}</div>
                </div>
              </div>
            ))}
          </div>
        )}

        <div style={S.content}>{renderPage()}</div>
      </div>
    </div>
  );
}
